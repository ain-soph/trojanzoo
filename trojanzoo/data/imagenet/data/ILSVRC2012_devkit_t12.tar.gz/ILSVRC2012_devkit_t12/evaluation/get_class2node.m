function class_str2node  = get_class2node(hash,wnid)
	class_str2node = hash.get(wnid);
end
